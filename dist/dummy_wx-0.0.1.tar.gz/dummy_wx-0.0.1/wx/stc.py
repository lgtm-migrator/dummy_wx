StyledTextCtrl = object
