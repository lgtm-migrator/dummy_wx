#!/usr/bin/env python
"""Setup script"""

from setuptools import setup, find_packages
setup(
       name               = "dummy_wx",
       packages           = find_packages(),
    )
