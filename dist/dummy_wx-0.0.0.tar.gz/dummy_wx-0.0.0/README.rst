****************
dummy_wx
****************

Dummy wxPython module to allow documentation to be built with ReadTheDocs